package DriverTest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class SQLDatabaseConnection {
// Connect to your database.
// Replace server name, username, and password with your credentials
public static void main(String[] args) throws SQLException {
String connectionUrl1 = "jdbc:sqlserver://localhost:13001;databaseName=Northwinds2020TSQLV6;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl1); Statement stmt=connection.createStatement();) {
// Code here.
System.out.println("Best easy: Easy Query 5");
 ResultSet results=stmt.executeQuery("Select customerid, customercompanyname, customercontactname, customercity, customercountry, \r\n" + 
 		"CASE customercountry\r\n" + 
 		"    When 'Argentina'	Then 'Latin American Airlines' \r\n" + 
 		"    When 'Austria'	    Then 'European Airlines'\r\n" + 
 		"    When 'Belgium'	    Then 'European Airlines'\r\n" + 
 		"    When 'Brazil'	    Then 'Latin American Airlines'\r\n" + 
 		"    When 'Canada'	    Then 'North American Airlines'\r\n" + 
 		"    When 'Denmark'	    Then 'European Airlines'\r\n" + 
 		"    When 'Finland'	    Then 'European Airlines'\r\n" + 
 		"    When 'France'	    Then 'European Airlines'\r\n" + 
 		"    When 'Germany'	    Then 'European Airlines'\r\n" + 
 		"    When 'Ireland'	    Then 'European Airlines'\r\n" + 
 		"    When 'Italy'	    Then 'European Airlines'\r\n" + 
 		"    When 'Mexico'	    Then 'Latin American Airlines'\r\n" + 
 		"    When 'Norway'	    Then 'European Airlines'\r\n" + 
 		"    When 'Poland'	    Then 'European Airlines'\r\n" + 
 		"    When 'Portugal'	    Then 'European Airlines'\r\n" + 
 		"    When 'Spain'	    Then 'European Airlines'\r\n" + 
 		"    When 'Sweden'	    Then 'European Airlines'\r\n" + 
 		"    When 'Switzerland'	Then 'European Airlines'\r\n" + 
 		"    When 'UK'	        Then 'European Airlines'\r\n" + 
 		"    When 'USA'	        Then 'North American Airlines'\r\n" + 
 		"    When 'Venezuela'	Then 'Latin American Airlines'\r\n" + 
 		"    ELSE 'Unknown Company'\r\n" + 
 		"  END AS airplanecompanytoshipby\r\n" + 
 		"From Sales.Customer;");
 while(results.next()) {
  System.out.println(results.getString("customerid")+","+results.getString("customercompanyname")+","
   +results.getString("customercontactname")+","+results.getString("customercity")+","+results.getString("customercountry"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl2 = "jdbc:sqlserver://localhost:13001;databaseName=AdventureWorks2017;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl2); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Best medium: Medium query 5");
 ResultSet results=stmt.executeQuery("Declare @money1 float =1.1, @money2 float=1.3, @money3 float=1.5, @money4 float=1.7, @money0 float=1.0\r\n" + 
 		"DROP TABLE IF EXISTS HumanResources.loggedinbusinessmembers;\r\n" + 
 		"Select E.BusinessEntityID, E.NationalIDNumber, E.LoginID,E.OrganizationNode, E.OrganizationLevel, E.JobTitle,EDH.DepartmentID,EDH.Shiftid, EPH.ratechangedate,CAST(EPH.rate as float) as floatrate,EPH.payfrequency\r\n" + 
 		"INTO HumanResources.loggedinbusinessmembers\r\n" + 
 		"From HumanResources.Employee as E\r\n" + 
 		" Left Outer Join HumanResources.EmployeeDepartmentHistory as EDH\r\n" + 
 		"  ON E.BusinessEntityID=EDH.BusinessEntityID\r\n" + 
 		" Left Outer Join HumanResources.EmployeePayHistory as EPH\r\n" + 
 		"  ON E.BusinessEntityID=EPH.BusinessEntityID\r\n" + 
 		"Group BY E.BusinessEntityID, E.NationalIDNumber, E.LoginID,E.OrganizationNode, E.OrganizationLevel, E.JobTitle,EDH.DepartmentID,EDH.Shiftid, EPH.ratechangedate, EPH.rate,EPH.payfrequency;\r\n" + 
 		"WITH BusinessCTE as \r\n" + 
 		"(\r\n" + 
 		"SELECT B.BusinessEntityID, B.NationalIDNumber, B.LoginID,B.OrganizationNode, B.OrganizationLevel, B.JobTitle,B.DepartmentID,B.Shiftid, B.ratechangedate,B.floatrate,B.payfrequency,\r\n" + 
 		"CASE B.OrganizationLevel\r\n" + 
 		" When 1 THEN B.floatrate*1.1\r\n" + 
 		" When 2 THEN B.floatrate*1.3\r\n" + 
 		" When 3 THEN B.floatrate*1.5\r\n" + 
 		" When 4 THEN B.floatrate*1.7 \r\n" + 
 		" Else B.floatrate*1.0\r\n" + 
 		"END AS raisedpayrate,SYSDATETIME()  as newratechangedate\r\n" + 
 		"From HumanResources.loggedinbusinessmembers as B)\r\n" + 
 		"Select *\r\n" + 
 		"From BusinessCTE\r\n" + 
 		"Where departmentid in (Select MAX(DepartmentID) from BusinessCTE) and  raisedpayrate<50\r\n" + 
 		"DROP TABLE IF EXISTS HumanResources.loggedinbusinessmembers");
 while(results.next()) {
  System.out.println(results.getString("BusinessEntityID")+","+results.getString("NationalIDNumber")+","
   +results.getString("LoginID")+","+results.getString("OrganizationNode")+","+results.getString("OrganizationNode")
   +","+results.getString("JobTitle")+","+results.getString("DepartmentID")+","+results.getString("ShiftId")+","+results.getString("ratechangedate")+","
   +results.getString("floatrate")+","+results.getString("payfrequency")+","+results.getString("raisedpayrate")+","
   +results.getString("newratechangedate"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl3 = "jdbc:sqlserver://localhost:13001;databaseName=TSQLV4;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl3); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Best hard: Hard query 1");
 ResultSet results=stmt.executeQuery(";Select Distinct  O.orderid,O.custid,O.empid,O.orderdate,O.requireddate,O.shippeddate,O.shipperid,O.freight,O.shipname,O.shipaddress,O.shipcity,O.shipregion,O.shippostalcode,O.shipcountry,C.companyname,Upper(C.contactname) as customername, Lower(H.FULLNAME) as employeename\r\n" + 
 		"From Sales.Searchfororderbycustandorderid(1,10000,1000) as O\r\n" + 
 		" Inner join Sales.Customers as C\r\n" + 
 		"  ON C.custid=O.custid\r\n" + 
 		" Inner Join HR.Employees as H\r\n" + 
 		"  ON H.empid=O.empid\r\n" + 
 		"Where year(orderdate) in (Select Max(year(orderdate)) from Sales.Orders);");
 while(results.next()) {
  System.out.println(results.getString("orderid")+","+results.getString("custid")+","
   +results.getString("empid")+","+results.getString("orderdate")+","+results.getString("requireddate")
   +","+results.getString("shippeddate")+","+results.getString("shipperid")+","+results.getString("freight")+","+results.getString("shipname")+","
   +results.getString("shipaddress")+","+results.getString("shipcity")+","+results.getString("shipregion")+","
   +results.getString("shippostalcode")+","+results.getString("shipcountry")+","+results.getString("companyname")+","+results.getString("customername")
   +","+results.getString("employeename"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl4 = "jdbc:sqlserver://localhost:13001;databaseName=TSQLV4;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl4); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Second best easy: Easy query 3");
 ResultSet results=stmt.executeQuery(";Select OD.orderid, O.custid,O.orderdate, (OD.unitprice*OD.qty*(1-OD.discount)) as overall_price,O.shipcountry,O.shipcity,OD.productid\r\n" + 
 		"From Sales.Orders as O\r\n" + 
 		" Inner Join Sales.OrderDetails as OD\r\n" + 
 		"  ON O.orderid = OD.orderid\r\n" + 
 		"Where (O.shipcountry = 'USA') AND (O.orderdate Between '20140214' and '20160214') AND (O.shipcity Like N'A%')\r\n" + 
 		"Order by O.custid, OD.orderid, O.orderdate;");
 while(results.next()) {
  System.out.println(results.getString("orderid")+","+results.getString("custid")+","+results.getString("orderdate")+","+results.getString("overall_price")
   +","+results.getString("shipcountry")+","+results.getString("shipcity")+","+results.getString("productid"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl5 = "jdbc:sqlserver://localhost:13001;databaseName=Northwinds2020TSQLV6;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl5); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Second best Medium: Medium query 3");
 ResultSet results=stmt.executeQuery(";With CategoryandProduct AS(\r\n" + 
 		"Select C.categoryid,C.categoryname,C.description,P.productid,P.productname,P.unitprice, P.discontinued\r\n" + 
 		"From Production.Category as C\r\n" + 
 		" Left outer join Production.Product as P\r\n" + 
 		"  On C.categoryid=P.categoryid\r\n" + 
 		"Group By C.categoryid,C.categoryname,C.description,P.productid,P.productname,P.unitprice, P.discontinued\r\n" + 
 		")\r\n" + 
 		"Select A.categoryid,A.categoryname,A.description,\r\n" + 
 		"(Select Max(B.unitprice) from categoryandproduct as B where B.categoryid=A.categoryid and B.discontinued=0) as maxpossibleprice,\r\n" + 
 		"(Select MIN(B.unitprice) from categoryandproduct as B where B.categoryid=A.categoryid and B.discontinued=0) as minpossibleprice\r\n" + 
 		"FROM categoryandproduct as A\r\n" + 
 		"Group by A.categoryid,A.categoryname,A.description\r\n" + 
 		"Order BY categoryid;");
 while(results.next()) {
  System.out.println(results.getString("categoryid")+","+results.getString("categoryname")+","+results.getString("description")+","+results.getString("maxpossibleprice")
   +","+results.getString("minpossibleprice"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl6 = "jdbc:sqlserver://localhost:13001;databaseName=TSQLV4;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl6); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Second best Hard: Hard query 2");
 ResultSet results=stmt.executeQuery(";Select O.orderid,A.custid,A.companyname,A.city, O.orderdate,B.empid,B.firstname,B.lastname,B.title,B.birthdate\r\n" + 
 		"From Sales.OrdersfromApril as O\r\n" + 
 		" Inner join Sales.Customers as A\r\n" + 
 		"  ON A.custid=O.custid\r\n" + 
 		" Inner join Sales.employeesbyCountry('USA') as B\r\n" + 
 		"  ON B.empid=O.empid\r\n" + 
 		"Where B.lastname in (Select lastname from HR.employees where lastname not like N'[FGT]%') \r\n" + 
 		"Group BY O.orderid,A.custid,A.companyname,A.city, O.orderdate,B.empid,B.firstname,B.lastname,B.title,B.birthdate\r\n" + 
 		"Order by B.empid,O.orderid;");
 while(results.next()) {
  System.out.println(results.getString("orderid")+","+results.getString("custid")+","+results.getString("companyname")+","+results.getString("city")
   +","+results.getString("orderdate")+","+results.getString("empid")+","+results.getString("firstname")+","+results.getString("lastname")
   +","+results.getString("title")+","+results.getString("birthdate"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl7 = "jdbc:sqlserver://localhost:13001;databaseName=AdventureWorksDW2017;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl7); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Worst easy: Easy query 1");
 ResultSet results=stmt.executeQuery(";Select A.geographykey, COUNT(*) as maleorders\r\n" + 
 		"From dbo.dimCustomer as A\r\n" + 
 		"Where (A.Gender='M') \r\n" + 
 		"Group by A.geographykey\r\n" + 
 		"Order by geographykey asc;");
 while(results.next()) {
  System.out.println(results.getString("geographykey")+","+results.getString("maleorders"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl8 = "jdbc:sqlserver://localhost:13001;databaseName=TSQLV4;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl8); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Worst Medium: Medium query 4");
 ResultSet results=stmt.executeQuery(";With EmployeeCTE AS(\r\n" + 
 		"Select H.empid,H.title,H.firstname, H.lastname, H.birthdate, H.hiredate, H.phone,ABS(DateDiff(year,H.hiredate,H.birthdate)) as ageofhire,ABS(Datediff(year,O.orderdate,H.hiredate)) as yearofworkdonewhenorderdone, O.orderid,O.orderdate,O.custid,(OD.unitprice*OD.qty*(1-OD.discount)) as overall_price\r\n" + 
 		"From HR.Employees as H\r\n" + 
 		" Left Outer Join Sales.Orders as O\r\n" + 
 		"  ON O.empid = H.empid\r\n" + 
 		" Left Outer Join Sales.OrderDetails as OD\r\n" + 
 		"  ON O.orderid = OD.orderid\r\n" + 
 		"Where O.shipcountry in (Select shipcountry from Sales.Orders where shipcountry = 'France') AND H.hiredate in(Select MIN(hiredate) from HR.Employees where hiredate < '20151212') AND H.birthdate in (Select birthdate from HR.Employees where birthdate < '19900101')\r\n" + 
 		"Group By H.empid,H.title,H.firstname, H.lastname, H.birthdate, H.hiredate, H.phone,O.orderid,O.orderdate,O.custid,OD.unitprice,OD.qty,OD.discount\r\n" + 
 		")\r\n" + 
 		"Select empid,title,firstname,lastname,birthdate,hiredate,phone,COUNT(*) as totalorders, SUM(overall_price) as totalpricesofallorders\r\n" + 
 		"From EmployeeCTE\r\n" + 
 		"Group BY empid,title,firstname,lastname,birthdate,hiredate,phone;");
 while(results.next()) {
  System.out.println(results.getString("empid")+","+results.getString("title")+","+results.getString("firstname")+","+results.getString("lastname")
   +","+results.getString("birthdate")+","+results.getString("hiredate")+","+results.getString("phone")+","+results.getString("totalorders")
   +","+results.getString("totalpricesofallorders"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
String connectionUrl9 = "jdbc:sqlserver://localhost:13001;databaseName=Adventureworks2017;user=sa;password=PH@123456789";
try (Connection connection = DriverManager.getConnection(connectionUrl9); Statement stmt=connection.createStatement();) {
// Code here.
 System.out.println("Worst Hard: Hard query 8");
 ResultSet results=stmt.executeQuery(";Select O.addresstypeid,O.name, O.addressid,O.addressline1,O.addressline2,O.city,O.stateprovinceid,O.postalcode,O.numpostalcodeperaddress\r\n" + 
 		"From Person.Personsearchbytype20 as O\r\n" + 
 		"Order by O.postalcode;");
 while(results.next()) {
  System.out.println(results.getString("addresstypeid")+","+results.getString("name")+","+results.getString("addressid")+","+results.getString("addressline1")
   +","+results.getString("addressline2")+","+results.getString("city")+","+results.getString("stateprovinceid")+","+results.getString("postalcode")
   +","+results.getString("numpostalcodeperaddress"));	 
 }
}
// Handle any errors that may have occurred.
catch (SQLException e) {
e.printStackTrace();
}
}
}